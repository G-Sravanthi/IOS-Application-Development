//
//  AppDelegate.h
//  converterProject
//
//  Created by Adeptpros on 02/09/1938 Saka.
//  Copyright © 1938 Saka Geniusport. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


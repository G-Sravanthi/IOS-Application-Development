//
//  main.m
//  converterProject
//
//  Created by Adeptpros on 02/09/1938 Saka.
//  Copyright © 1938 Saka Geniusport. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

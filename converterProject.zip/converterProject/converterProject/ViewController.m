//
//  ViewController.m
//  converterProject
//
//  Created by Adeptpros on 02/09/1938 Saka.
//  Copyright © 1938 Saka Geniusport. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIPickerViewDelegate,UIPickerViewDataSource>
{
    NSArray *Array;
    //NSString *selectedEntry;
}

@property (strong, nonatomic) IBOutlet UISegmentedControl *segmentOutlet;

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    _selectedValues=[[NSMutableArray alloc]initWithObjects:@"   ",@"    ", nil];
    
    if (_segmentOutlet.selectedSegmentIndex==0){
        Array=@[@"Ruppee",@"American Dollar",@"Euro",@"Dinar",@"Canadian Dollar"];
    }
    
    if (_segmentOutlet.selectedSegmentIndex==1){
        Array=@[@"Feet",@"Meter ",@"inch",@"yard",@"miles"];
    }
    if (_segmentOutlet.selectedSegmentIndex==2){
        Array=@[@"Kilogram",@"Pound",@"Ounce",@"grams",@"Tons"];
    }
    
    self.fromPickerOutlet.dataSource = self;
    self.fromPickerOutlet.delegate = self;
    
    }

//FROM PICKER
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    
    NSInteger result = 0;
    if ([pickerView isEqual:self.fromPickerOutlet]){
        result = 2;
    }
    return result;
    
}

- (NSInteger)   pickerView:(UIPickerView *)pickerView
   numberOfRowsInComponent:(NSInteger)component{
    return Array.count;
    
}



- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return Array[row];
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
    

        _selectedEntry = [Array objectAtIndex:row];
        
    
    //NSLog(@"first property %@",_selectedEntry);
    
    [_selectedValues addObject:_selectedEntry];
    
   // NSLog(@"input array has %@  ",_selectedValues);
    
    _countOfSelectedValues=[_selectedValues count];
    
    //NSLog(@"%ld",(long)_countOfSelectedValues);
    
        _firstEntry=[_selectedValues objectAtIndex:_countOfSelectedValues -2];
        _secondEntry=[_selectedValues objectAtIndex:_countOfSelectedValues-1];
    
        NSLog(@" Firstly Selected Value is     :-     %@",_firstEntry);
        NSLog(@"Secondly Selected Value is  :-     %@   \n ",_secondEntry);
    
    

}



- (IBAction)slider:(id)sender {
    [self.sliderOutlet addTarget:self action:@selector(slider:) forControlEvents:UIControlEventValueChanged];
    
    NSString *str=[NSString stringWithFormat:@"%f",[self.sliderOutlet value]];
    
    _inputTextFeild.text=str;
    

}



//Distance

- (IBAction)segmentAction:(id)sender {
    
    if (_segmentOutlet.selectedSegmentIndex==0) {
        
        
        _inputSideLabel.text=@"Amount";
        _outputSideLabel.text=@"Converted Amout ";
        
        
            Array=@[@"Ruppee",@"American Dollar",@"Euro",@"Dinar",@"Canadian Dollar"];
        
  
    }
    
    
    
    
    if (_segmentOutlet.selectedSegmentIndex==1) {
        
        
        _inputSideLabel.text=@"Distance";
        _outputSideLabel.text=@"Converted Distance ";
        Array=@[@"Feet",@"Meter ",@"Inch",@"Yard",@"Miles"];
        
    }
    
    
    
    
    if (_segmentOutlet.selectedSegmentIndex==2) {
        
        
        _inputSideLabel.text=@"Weight";
        _outputSideLabel.text=@"Converted Weight ";
        Array=@[@"Kilogram",@"Pound",@"Ounce",@"Grams",@"Tons"];

        
    }
    
    
    
    
}


- (IBAction)convertButton:(id)sender {

    if (_segmentOutlet.selectedSegmentIndex==0) {
        
        NSString *s1=_inputTextFeild.text;
        
        double k=[s1 doubleValue];
        

    //Ruppee
        
        if ([_firstEntry  isEqualToString:@"Ruppee"]) {
            
            if ([_secondEntry isEqualToString:@"American Dollar"]) {
                
                k=(k*1/68);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Euro"]) {
                
                k=(k*1/80);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Dinar"]) {
                
                k=(k*1/200);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Canadian Dollar"]) {
                
                k=(k*1/40);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Ruppee"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }

            
}
        
        
        
        //American Dollar
        
        
        if ([_firstEntry  isEqualToString:@"American Dollar"]) {
            
            if ([_secondEntry isEqualToString:@"American Dollar"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Euro"]) {
                
                k=(k*.8);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Dinar"]) {
                
                k=(k*.3);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Canadian Dollar"]) {
                
                k=(k*1.5);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Ruppee"]) {
                
                k=(k*67);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
            
        }
        
        
        
        
        //Euro
        
        if ([_firstEntry  isEqualToString:@"Euro"]) {
            
            if ([_secondEntry isEqualToString:@"American Dollar"]) {
                
                k=(k*1.2);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Euro"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Dinar"]) {
                
                k=(k*1/2.5);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Canadian Dollar"]) {
                
                k=(k*2);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Ruppee"]) {
                
                k=(k*80);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
            
        }
        
        
        
        //Dinar
        
        
        if ([_firstEntry  isEqualToString:@"Dinar"]) {
            
            if ([_secondEntry isEqualToString:@"American Dollar"]) {
                
                k=(k*3);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Euro"]) {
                
                k=(k*2.5);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Dinar"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Canadian Dollar"]) {
                
                k=(k*5);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Ruppee"]) {
                
                k=(k*200);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
            
        }
        
        
        //Canadian Dollar
        
        
        if ([_firstEntry  isEqualToString:@"Canadian Dollar"]) {
            
            if ([_secondEntry isEqualToString:@"American Dollar"]) {
                
                k=(k*0.6);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Euro"]) {
                
                k=(k*1/2);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Dinar"]) {
                
                k=(k*1/5);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Canadian Dollar"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Ruppee"]) {
                
                k=(k*40);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
            
        }
        
        
    
    
    
    
    
        
    
}

    
    
    
    
    
    
    if (_segmentOutlet.selectedSegmentIndex==1) {
        
        
        
        NSString *s1=_inputTextFeild.text;
        
        double k=[s1 doubleValue];
        
        
        //Feet
        
        if ([_firstEntry  isEqualToString:@"Feet"]) {
            
            if ([_secondEntry isEqualToString:@"Meter"]) {
                
                k=(k*0.304  );
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Inch"]) {
                
                k=(k*12);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Yard"]) {
                
                k=(k*0.333);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Miles"]) {
                
                k=(k*0.00018);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Feet"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }
        

        //Meter
        
        if ([_firstEntry  isEqualToString:@"Meter"]) {
            
            if ([_secondEntry isEqualToString:@"Meter"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Inch"]) {
                
                k=(k*39.37);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Yard"]) {
                
                k=(k*1.093);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Miles"]) {
                
                k=(k/0.00062);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Feet"]) {
                
                k=(k*3.28);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }
        
        
        
        
        //Inch
        
        if ([_firstEntry  isEqualToString:@"Inch"]) {
            
            if ([_secondEntry isEqualToString:@"Meter"]) {
                
                k=(k*0.025);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Inch"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Yard"]) {
                
                k=(k*0.027);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Miles"]) {
                
                k=(k/63360);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Feet"]) {
                
                k=(k*0.088);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }
        

        
        
        //Yard
        
        if ([_firstEntry  isEqualToString:@"Yard"]) {
            
            if ([_secondEntry isEqualToString:@"Meter"]) {
                
                k=(k*0.911);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Inch"]) {
                
                k=(k*36);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Yard"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Miles"]) {
                
                k=(k*0.00056);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Feet"]) {
                
                k=(k*3);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }
        

        
        
        //Mile
        
        if ([_firstEntry  isEqualToString:@"Mile"]) {
            
            if ([_secondEntry isEqualToString:@"Meter"]) {
                
                k=(k*1609);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Inch"]) {
                
                k=(k*63360);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Yard"]) {
                
                k=(k*1760);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Miles"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Feet"]) {
                
                k=(k*5280);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }
        

        
    }
    
    
    

    
    if (_segmentOutlet.selectedSegmentIndex==2) {
        
        NSString *s1=_inputTextFeild.text;
        
        double k=[s1 doubleValue];
        
        
        
        //Kilogram
        
        if ([_firstEntry  isEqualToString:@"Kilogram"]) {
            
            if ([_secondEntry isEqualToString:@"Pound"]) {
                
                k=(k*2.2);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Ounce"]) {
                
                k=(k*35.27);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Grams"]) {
                
                k=(k*1000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Tons"]) {
                
                k=(k/1000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Kilogram"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }
        
        
        //Ounce
        
        if ([_firstEntry  isEqualToString:@"Ounce"]) {
            
            if ([_secondEntry isEqualToString:@"Pound"]) {
                
                k=(k*0.028);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Ounce"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Grams"]) {
                
                k=(k*28.34);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Tons"]) {
                
                k=(k*28340000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Kilogram"]) {
                
                k=(k*28340);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }     //Pound
        
        if ([_firstEntry  isEqualToString:@"Pound"]) {
            
            if ([_secondEntry isEqualToString:@"Pound"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Ounce"]) {
                
                k=(k*16);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Grams"]) {
                
                k=(k*483);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Tons"]) {
                
                k=(k*483000000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Kilogram"]) {
                
                k=(k*483000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }     //Grams
        
        if ([_firstEntry  isEqualToString:@"Grams"]) {
            
            if ([_secondEntry isEqualToString:@"Pound"]) {
                
                k=(k*0.0022);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Ounce"]) {
                
                k=(k*0.035);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Grams"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Tons"]) {
                
                k=(k/1000000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Kilogram"]) {
                
                k=(k/1000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }     //Tons
        
        if ([_firstEntry  isEqualToString:@"Tons"]) {
            
            if ([_secondEntry isEqualToString:@"Pound"]) {
                
                k=(k*2000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            else if ([_secondEntry isEqualToString:@"Ounce"]) {
                
                k=(k*32000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Grams"]) {
                
                k=(k*1000000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }            else if ([_secondEntry isEqualToString:@"Tons"]) {
                
                k=(k*1);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            else if([_secondEntry isEqualToString:@"Kilogram"]) {
                
                k=(k*1000);
                
                NSString *s=[NSString stringWithFormat:@"%f",k];
                
                _OutputTextfeild.text=s;
                
            }
            
            
        }
        
        
    
        
    }


}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

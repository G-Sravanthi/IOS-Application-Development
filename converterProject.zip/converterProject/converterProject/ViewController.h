//
//  ViewController.h
//  converterProject
//
//  Created by Adeptpros on 02/09/1938 Saka.
//  Copyright © 1938 Saka Geniusport. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>
@property (strong, nonatomic) IBOutlet UILabel *inputSideLabel;
@property (strong, nonatomic) IBOutlet UILabel *outputSideLabel;
@property (strong, nonatomic) IBOutlet UITextField *inputTextFeild;

@property (strong, nonatomic) IBOutlet UISlider *sliderOutlet;

@property (strong, nonatomic) IBOutlet UITextField *OutputTextfeild;

@property (strong, nonatomic) IBOutlet UIPickerView *fromPickerOutlet;


// Own Properties

@property NSInteger *inputObserver;
@property(strong,nonatomic) NSString *selectedEntry;
@property(strong,nonatomic) NSString *firstEntry;
@property(strong,nonatomic) NSString *secondEntry;
@property (strong,nonatomic)NSMutableArray *selectedValues;
@property NSInteger countOfSelectedValues;


@end

